CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('superadmin','admin','viewer') NOT NULL DEFAULT 'viewer',
    email VARCHAR(100),
    department VARCHAR(100),
    status TINYINT DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Superadmin: username=superadmin, password=Superadmin123
-- Admin: username=admin, password=Admin123
-- Viewer: username=viewer, password=Viewer123

INSERT INTO users (username, password, role, email, department) VALUES
('superadmin', '$2y$10$F0UIz0EzGJ7JJ8W4w1F0KOKu/AD4NEKFKyVfNVz8UsNK3wlBNj5ja', 'superadmin', 'superadmin@polyparts.com', 'QA'),
('admin', '$2y$10$4UByi6dvufJ/5TF5iUyEGOwmbA8m5Cu4iT6F2xF/tghAlIT1xU7p6', 'admin', 'admin@polyparts.com', 'Production'),
('viewer', '$2y$10$tUukTXBRZyfr0rZb6Dj0BuvTFe5kZSLnA4YOQFXYf7nWGVqghJc2y', 'viewer', 'viewer@polyparts.com', 'HR');

CREATE TABLE documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_no VARCHAR(50) NOT NULL,
    revision VARCHAR(10) NOT NULL,
    title VARCHAR(255) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    retention VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    pic VARCHAR(100) NOT NULL,
    uploaded_by INT NOT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    remarks TEXT,
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

CREATE TABLE audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255),
    document_id INT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
