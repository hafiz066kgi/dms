<?php include_once __DIR__ . '/../templates/header.php'; ?>
<div class="container text-center py-5">
    <h1 class="display-3">404</h1>
    <p class="lead">Page Not Found</p>
    <a href="index.php" class="btn btn-primary">Back to Dashboard</a>
</div>
<?php include_once __DIR__ . '/../templates/footer.php'; ?>
